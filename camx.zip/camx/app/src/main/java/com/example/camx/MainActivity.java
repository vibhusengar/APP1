package com.example.camx;

import static android.view.Surface.CHANGE_FRAME_RATE_ALWAYS;
import static android.view.Surface.FRAME_RATE_COMPATIBILITY_DEFAULT;
import static android.view.Surface.FRAME_RATE_COMPATIBILITY_FIXED_SOURCE;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.CamcorderProfile;
import android.media.Image;
import android.media.ImageReader;
import android.media.MediaRecorder;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.SystemClock;
import android.os.Bundle;
import android.util.Log;
import android.util.Range;
import android.util.Size;
import android.util.SparseIntArray;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;


import com.google.android.material.slider.Slider;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Vector;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "Camera2VideoImageActivi";

    private static final int REQUEST_CAMERA_PERMISSION_RESULT = 0;
    private static final int REQUEST_WRITE_EXTERNAL_STORAGE_PERMISSION_RESULT = 1;
    private static final int STATE_PREVIEW = 0;
    private static final int STATE_WAIT_LOCK = 1;
    private Range<Integer> desiredFpsRange;
    private int count=0;
    private int mCaptureState = STATE_PREVIEW;
    int cameraFacing = CameraCharacteristics.LENS_FACING_BACK;
    private TextureView mTextureView;
    private LinearLayout linear, linear1;
    private Vector<byte[]> vImage = new Vector<byte[]>();
    private TextureView.SurfaceTextureListener mSurfaceTextureListener = new TextureView.SurfaceTextureListener() {
        @Override
        public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {
            setupCamera(width, height);
            connectCamera();
        }

        @Override
        public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {

        }

        @Override
        public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) {
            return false;
        }

        @Override
        public void onSurfaceTextureUpdated(SurfaceTexture surface) {

        }
    };
    private CameraDevice mCameraDevice;
    private CameraDevice.StateCallback mCameraDeviceStateCallback = new CameraDevice.StateCallback() {
        @Override
        public void onOpened(CameraDevice camera) {
            mCameraDevice = camera;
            mMediaRecorder = new MediaRecorder();
            if(mIsRecording) {
                try {
                    createVideoFileName();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                vImage.clear();
                vTime.clear();
                startRecord();
                mMediaRecorder.start();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mChronometer.setBase(SystemClock.elapsedRealtime());
                        mChronometer.setVisibility(View.VISIBLE);
                        mChronometer.start();
                        startStopwatch();
                    }
                });
            } else {
                startPreview();
            }
            // Toast.makeText(getApplicationContext(),
            //         "Camera connection made!", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onDisconnected(CameraDevice camera) {
            camera.close();
            mCameraDevice = null;
        }

        @Override
        public void onError(CameraDevice camera, int error) {
            camera.close();
            mCameraDevice = null;
        }
    };
    private HandlerThread mBackgroundHandlerThread;
    private Handler mBackgroundHandler;
    private String mCameraId;
    private Size mPreviewSize;
    private Size mVideoSize;
    private Size mImageSize;
    private ImageReader mImageReader;
    private  int format;
    private final ImageReader.OnImageAvailableListener mOnImageAvailableListener = new
            ImageReader.OnImageAvailableListener() {
                @Override
                public void onImageAvailable(ImageReader reader) {
                    mBackgroundHandler.post(new ImageSaver(reader.acquireLatestImage()));
                }
            };
    private class ImageSaver implements Runnable {

        private final Image mImage;

        public ImageSaver(Image image) {
            mImage = image;
        }

        @Override
        public void run() {
            ByteBuffer byteBuffer = mImage.getPlanes()[0].getBuffer();
            byte[] bytes = new byte[byteBuffer.remaining()];
            byteBuffer.get(bytes);

            FileOutputStream fileOutputStream = null;
            try {
                fileOutputStream = new FileOutputStream(mImageFileName);
                fileOutputStream.write(bytes);
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                mImage.close();

                Intent mediaStoreUpdateIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                mediaStoreUpdateIntent.setData(Uri.fromFile(new File(mImageFileName)));
                sendBroadcast(mediaStoreUpdateIntent);

                if(fileOutputStream != null) {
                    try {
                        fileOutputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

        }
    }
    private MediaRecorder mMediaRecorder;
    private Chronometer mChronometer;
    private int mTotalRotation;
    private CameraCaptureSession mPreviewCaptureSession;
    private CameraCaptureSession.CaptureCallback mPreviewCaptureCallback = new
            CameraCaptureSession.CaptureCallback() {

                private void process(CaptureResult captureResult) {
                    switch (mCaptureState) {
                        case STATE_PREVIEW:
                            // Do nothing
                            break;
                        case STATE_WAIT_LOCK:
                            mCaptureState = STATE_PREVIEW;
                            Integer afState = captureResult.get(CaptureResult.CONTROL_AF_STATE);
                            if(afState!=0 || cameraFacing==0) {
                                startStillCaptureRequest();
                            }
//                            if(afState == CaptureResult.CONTROL_AF_STATE_FOCUSED_LOCKED ||
//                                    afState == CaptureResult.CONTROL_AF_STATE_NOT_FOCUSED_LOCKED) {
//                                Toast.makeText(getApplicationContext(), "AF Locked!", Toast.LENGTH_SHORT).show();
//                                startStillCaptureRequest();
//                            }
                            break;
                    }
                }

                @Override
                public void onCaptureCompleted(CameraCaptureSession session, CaptureRequest request, TotalCaptureResult result) {
                    super.onCaptureCompleted(session, request, result);

                    process(result);
                }
            };
    private CameraCaptureSession mRecordCaptureSession;
    private CameraCaptureSession.CaptureCallback mRecordCaptureCallback = new
            CameraCaptureSession.CaptureCallback() {

                private void process(CaptureResult captureResult) {
                    switch (mCaptureState) {
                        case STATE_PREVIEW:
                            // Do nothing
                            break;
                        case STATE_WAIT_LOCK:
                            mCaptureState = STATE_PREVIEW;
                            Integer afState = captureResult.get(CaptureResult.CONTROL_AF_STATE);
                            if(afState!=0) {
                                startStillCaptureRequest();
                            }
//                            if(afState == CaptureResult.CONTROL_AF_STATE_FOCUSED_LOCKED ||
//                                    afState == CaptureResult.CONTROL_AF_STATE_NOT_FOCUSED_LOCKED) {
//                                Toast.makeText(getApplicationContext(), "AF Locked!", Toast.LENGTH_SHORT).show();
//                                startStillCaptureRequest();
//                            }
                            break;
                    }
                }

                @Override
                public void onCaptureCompleted(CameraCaptureSession session, CaptureRequest request, TotalCaptureResult result) {
                    super.onCaptureCompleted(session, request, result);

                    process(result);
                }
            };
    private CaptureRequest.Builder mCaptureRequestBuilder;

    private ImageButton capture, toggleFlash, flipCamera;
    private boolean mIsRecording = false;
    private boolean mIsTimelapse = false;
    private  boolean take=false;
    private boolean isback=true;

    private File mVideoFolder;
    private String mVideoFileName;
    private File mImageFolder;
    private File file;
    private File mFrameFolder;
    private String mImageFileName;
    private Button photo, video;
    private int bytesize=0;
    private int CIRfrequency=30;
    private String filePath;

    private static SparseIntArray ORIENTATIONS = new SparseIntArray();
    static {
        ORIENTATIONS.append(Surface.ROTATION_0, 0);
        ORIENTATIONS.append(Surface.ROTATION_90, 90);
        ORIENTATIONS.append(Surface.ROTATION_180, 180);
        ORIENTATIONS.append(Surface.ROTATION_270, 270);
    }

    private static class CompareSizeByArea implements Comparator<Size> {

        @Override
        public int compare(Size lhs, Size rhs) {
            return Long.signum( (long)(lhs.getWidth() * lhs.getHeight()) -
                    (long)(rhs.getWidth() * rhs.getHeight()));
        }
    }
    private Handler handler;
    private List<Long> timestamps, vTime;
    private Runnable stopwatchRunnable;
    private Slider slider;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        createVideoFolder();
        createImageFolder();
        setUpFolderPath();
        desiredFpsRange = new Range<>(60, 60); // Change this to desired frame rate range
        handler = new Handler();
        timestamps = new ArrayList<>();
        vTime = new ArrayList<>();

        slider = findViewById(R.id.slider);
        slider.addOnChangeListener(new Slider.OnChangeListener() {
            @Override
            public void onValueChange(Slider slider, float value, boolean fromUser) {
                // Handle value changes
                CIRfrequency =  (int)(slider.getValue()) ; // Get the current value of the slider
                // You can use the sliderValue as needed
            }
        });

        linear = (LinearLayout) findViewById(R.id.linear);
        linear1 = (LinearLayout) findViewById(R.id.linear1);
        mChronometer = (Chronometer) findViewById(R.id.chronometer);
        mTextureView = (TextureView) findViewById(R.id.textureView);
//        toggleFlash = findViewById(R.id.toggleFlash);
        flipCamera = findViewById(R.id.flipCamera);
        photo = findViewById(R.id.photo);
        video = findViewById(R.id.video);
        photo.setOnClickListener(view -> {
            if(mIsRecording){
                stopRecord();
//                storeFrames();
                saveVectorToExcel();
                vImage.clear();
                vTime.clear();
                count=0;
            }
            take=true;
            linear1.setVisibility(View.INVISIBLE);
            capture.setImageResource(R.drawable.baseline_camera_24);
            photo.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.yello));
            video.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.white));
        });

        video.setOnClickListener(view -> {
            linear1.setVisibility(View.VISIBLE);
            capture.setImageResource(R.drawable.round_fiber_manual_record_24);
            photo.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.white));
            video.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.yello));
            take=false;
        });
        capture = (ImageButton) findViewById(R.id.capture);
        capture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (take) {
                    checkWriteStoragePermission();
                }
                else {
                    if (mIsRecording) {
                        stopRecord();
//                        Toast.makeText(MainActivity.this, String.valueOf(vTime.get(vTime.size()-1))+" "+String.valueOf(timestamps.size()), Toast.LENGTH_LONG).show();

//                        storeFrames();
                        saveVectorToExcel();
                        vImage.clear();
                        vTime.clear();
                        timestamps.clear();
                        count=0;

                    } else {
                        mIsRecording = true;
                        capture.setImageResource(R.drawable.round_stop_circle_24);
                        checkWriteStoragePermission();
                    }
                }
            }
        });

        flipCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cameraFacing == CameraCharacteristics.LENS_FACING_BACK) {
                    cameraFacing = CameraCharacteristics.LENS_FACING_FRONT;
                } else {
                    cameraFacing = CameraCharacteristics.LENS_FACING_BACK;
                }
                closeCamera();
                setupCamera(mTextureView.getWidth(), mTextureView.getHeight());
                connectCamera();
            }
        });
    }

    @Override
    public void onBackPressed() {
        if(mIsRecording){
            stopRecord();
//            Toast.makeText(MainActivity.this, Integer.toString(count), Toast.LENGTH_LONG).show();

//                        storeFrames();
            saveVectorToExcel();
            vImage.clear();
            vTime.clear();
            count=0;
        }
        this.finishAffinity();
    }

    private  void stopRecord(){
        mChronometer.stop();
        mChronometer.setVisibility(View.INVISIBLE);
        mIsRecording = false;
        linear1.setVisibility(View.VISIBLE);
        linear.setVisibility(View.VISIBLE);
        flipCamera.setVisibility(View.VISIBLE);

        // Starting the preview prior to stopping recording which should hopefully
        // resolve issues being seen in Samsung devices.
        stopStopwatch();
        startPreview();
        try {
            mMediaRecorder.stop();
        } catch (Exception e) {
            Toast.makeText(MainActivity.this, "Prepare 1 Error: " + e, Toast.LENGTH_SHORT).show();
        }
        mMediaRecorder.reset();

        Intent mediaStoreUpdateIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
        mediaStoreUpdateIntent.setData(Uri.fromFile(new File(mVideoFileName)));
        sendBroadcast(mediaStoreUpdateIntent);
        capture.setImageResource(R.drawable.round_fiber_manual_record_24);
        Toast.makeText(this, "Timestamp mapping is in process", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();

        startBackgroundThread();

        if(mTextureView.isAvailable()) {
            setupCamera(mTextureView.getWidth(), mTextureView.getHeight());
            connectCamera();
        } else {
            mTextureView.setSurfaceTextureListener(mSurfaceTextureListener);
        }
        stopwatchRunnable = new Runnable() {
            @Override
            public void run() {
                recordTimestamp();
                handler.postDelayed(this, 1000/CIRfrequency); // Record frequency: 1 second
            }
        };
    }

//    @Override
//    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//        if(requestCode == REQUEST_CAMERA_PERMISSION_RESULT) {
//            if(grantResults[0] != PackageManager.PERMISSION_GRANTED) {
//                Toast.makeText(getApplicationContext(),
//                        "Application will not run without camera services", Toast.LENGTH_SHORT).show();
//            }
//            if(grantResults[1] != PackageManager.PERMISSION_GRANTED) {
//                Toast.makeText(getApplicationContext(),
//                        "Application will not have audio on record", Toast.LENGTH_SHORT).show();
//            }
//        }
//        if(requestCode == REQUEST_WRITE_EXTERNAL_STORAGE_PERMISSION_RESULT) {
//            if(grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                if(mIsRecording) {
//                    mIsRecording = true;
//                    capture.setImageResource(R.drawable.round_stop_circle_24);
//                }
//                Toast.makeText(this,
//                        "Permission successfully granted!", Toast.LENGTH_SHORT).show();
//            } else {
//                Toast.makeText(this,
//                        "App needs to save video to run", Toast.LENGTH_SHORT).show();
//            }
//        }
//    }

    @Override
    protected void onPause() {
        closeCamera();

        stopBackgroundThread();

        super.onPause();

        handler.removeCallbacks(stopwatchRunnable);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocas) {
        super.onWindowFocusChanged(hasFocas);
        View decorView = getWindow().getDecorView();
        if(hasFocas) {
            decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        }
    }

    private void setupCamera(int width, int height) {
        CameraManager cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            for(String cameraId : cameraManager.getCameraIdList()){
                CameraCharacteristics cameraCharacteristics = cameraManager.getCameraCharacteristics(cameraId);
                if(cameraCharacteristics.get(CameraCharacteristics.LENS_FACING) != cameraFacing){
                    continue;
                }
                StreamConfigurationMap map = cameraCharacteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                int deviceOrientation = getWindowManager().getDefaultDisplay().getRotation();
                mTotalRotation = sensorToDeviceRotation(cameraCharacteristics, deviceOrientation);
                boolean swapRotation = mTotalRotation == 90 || mTotalRotation == 270;
                int rotatedWidth = width;
                int rotatedHeight = height;
                if(swapRotation) {
                    rotatedWidth = height;
                    rotatedHeight = width;
                }
                mPreviewSize = chooseOptimalSize(map.getOutputSizes(SurfaceTexture.class), rotatedWidth, rotatedHeight);
                mVideoSize = chooseOptimalSize(map.getOutputSizes(MediaRecorder.class), rotatedWidth, rotatedHeight);
                mImageSize = chooseOptimalSize(map.getOutputSizes(ImageFormat.JPEG), rotatedWidth, rotatedHeight);
                mImageReader = ImageReader.newInstance(mImageSize.getWidth(), mImageSize.getHeight(), ImageFormat.JPEG, 1);
                mImageReader.setOnImageAvailableListener(mOnImageAvailableListener, mBackgroundHandler);
                mCameraId = cameraId;
                return;
            }
        } catch (CameraAccessException e) {
            Toast.makeText(this, "Error: "+e, Toast.LENGTH_SHORT).show();
        }
    }

    private void connectCamera() {
        CameraManager cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if(ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA) ==
                        PackageManager.PERMISSION_GRANTED) {
                    cameraManager.openCamera(mCameraId, mCameraDeviceStateCallback, mBackgroundHandler);
                } else {
                    if(shouldShowRequestPermissionRationale(android.Manifest.permission.CAMERA)) {
                        Toast.makeText(this,
                                "Video app required access to camera", Toast.LENGTH_SHORT).show();
                    }
                    requestPermissions(new String[] {android.Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO
                    }, REQUEST_CAMERA_PERMISSION_RESULT);
                }

            } else {
                cameraManager.openCamera(mCameraId, mCameraDeviceStateCallback, mBackgroundHandler);
            }
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    private void startRecord() {

        try {
            if(mIsRecording) {
                setupMediaRecorder();
            }
            SurfaceTexture surfaceTexture = mTextureView.getSurfaceTexture();
            surfaceTexture.setDefaultBufferSize(mPreviewSize.getWidth(), mPreviewSize.getHeight());
            Surface previewSurface = new Surface(surfaceTexture);
            mCaptureRequestBuilder = mCameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_RECORD);
//            mCaptureRequestBuilder.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, desiredFpsRange);
            Surface recordSurface = mMediaRecorder.getSurface();
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
////                Toast.makeText(this, Integer.toString(Build.VERSION.SDK_INT), Toast.LENGTH_SHORT).show();
////                previewSurface.setFrameRate(60,  FRAME_RATE_COMPATIBILITY_FIXED_SOURCE);
//                recordSurface.setFrameRate(15,  FRAME_RATE_COMPATIBILITY_FIXED_SOURCE);
//            }
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
//                Toast.makeText(this, Integer.toString(Build.VERSION.SDK_INT), Toast.LENGTH_SHORT).show();
////                previewSurface.setFrameRate(60,  FRAME_RATE_COMPATIBILITY_FIXED_SOURCE);
//                recordSurface.setFrameRate(15,  FRAME_RATE_COMPATIBILITY_FIXED_SOURCE, CHANGE_FRAME_RATE_ALWAYS);
//            }
            mImageReader = ImageReader.newInstance(mPreviewSize.getWidth(), mPreviewSize.getHeight(),
                    ImageFormat.JPEG, 1); // Adjust the format and maxImages as needed

            // Set up OnImageAvailableListener to capture frames with timestamps
            mImageReader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                @Override
                public void onImageAvailable(ImageReader reader) {
//                    count++;
                    Image image = reader.acquireLatestImage();
                    if (image != null) {
                        count++;
                        long timestamp = image.getTimestamp();
                        try {
                            //get image buffer
//                            ByteBuffer buffer = image.getPlanes()[0].getBuffer();
//                            byte[] bytes = new byte[buffer.capacity()];
//                            buffer.get(bytes);
//                            bytesize=bytes.length;
//                            vImage.add(bytes);
                            vTime.add(timestamp);
                            // create bitmap
//                            Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length,null);
//                         Save the frame data and timestamp to a file
//                            saveFrameToFile(bitmap, timestamp);
                        }
                        catch(Exception e){
                            if(count==0) Toast.makeText(MainActivity.this, "Error1: "+e, Toast.LENGTH_SHORT).show();
                        }
                        image.close();
                    }
                }
            }, mBackgroundHandler);
            Surface imageSurface = mImageReader.getSurface();
            mCaptureRequestBuilder.addTarget(previewSurface);
            mCaptureRequestBuilder.addTarget(recordSurface);
            mCaptureRequestBuilder.addTarget(imageSurface);
//            mCaptureRequestBuilder.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_OFF);
//            mCaptureRequestBuilder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF);
//            mCaptureRequestBuilder.set(CaptureRequest.SENSOR_FRAME_DURATION, (long) (1e9 / desiredFpsRange.getUpper()));


            mCameraDevice.createCaptureSession(Arrays.asList(previewSurface, recordSurface, imageSurface),
                    new CameraCaptureSession.StateCallback() {
                        @Override
                        public void onConfigured(CameraCaptureSession session) {
                            mRecordCaptureSession = session;
                            try {
                                mRecordCaptureSession.setRepeatingRequest(
                                        mCaptureRequestBuilder.build(), null, null
                                );
                            } catch (CameraAccessException e) {
                                e.printStackTrace();
                            }
                        }

                        @Override
                        public void onConfigureFailed(CameraCaptureSession session) {
                            Log.d(TAG, "onConfigureFailed: startRecord");
                        }
                    }, null);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private void startPreview() {
        SurfaceTexture surfaceTexture = mTextureView.getSurfaceTexture();
        surfaceTexture.setDefaultBufferSize(mPreviewSize.getWidth(), mPreviewSize.getHeight());
        Surface previewSurface = new Surface(surfaceTexture);

        try {
            mCaptureRequestBuilder = mCameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            mCaptureRequestBuilder.addTarget(previewSurface);
//            mCaptureRequestBuilder.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, desiredFpsRange);

//            mImageReader = ImageReader.newInstance(mPreviewSize.getWidth(), mPreviewSize.getHeight(),
//                    ImageFormat.JPEG, 2); // Adjust the format and maxImages as needed
//
//            // Set up OnImageAvailableListener to capture frames with timestamps
//            mImageReader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
//                @Override
//                public void onImageAvailable(ImageReader reader) {
////                    count++;
//                    Image image = reader.acquireLatestImage();
//                    if (image != null) {
//                        count++;
//                        long timestamp = image.getTimestamp();
//                        try {
//                            //get image buffer
//                            ByteBuffer buffer = image.getPlanes()[0].getBuffer();
//                            byte[] bytes = new byte[buffer.capacity()];
//                            buffer.get(bytes);
//                            vImage.add(bytes);
//                            vTime.add(timestamp);
//                            // create bitmap
////                            Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length,null);
////                         Save the frame data and timestamp to a file
////                            saveFrameToFile(bitmap, timestamp);
//                        }
//                        catch(Exception e){
//                            if(count==0) Toast.makeText(MainActivity.this, "Error1: "+e, Toast.LENGTH_SHORT).show();
//                        }
//                        image.close();
//                    }
//                }
//            }, mBackgroundHandler);

            mCameraDevice.createCaptureSession(Arrays.asList(previewSurface, mImageReader.getSurface()),
                    new CameraCaptureSession.StateCallback() {
                        @Override
                        public void onConfigured(CameraCaptureSession session) {
                            Log.d(TAG, "onConfigured: startPreview");
                            mPreviewCaptureSession = session;
                            try {
                                mPreviewCaptureSession.setRepeatingRequest(mCaptureRequestBuilder.build(),
                                        null, mBackgroundHandler);
                            } catch (CameraAccessException e) {
                                e.printStackTrace();
                            }
                        }

                        @Override
                        public void onConfigureFailed(CameraCaptureSession session) {
                            Log.d(TAG, "onConfigureFailed: startPreview");

                        }
                    }, null);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }
    private Bitmap imageToBitmap(Image image) {
        ByteBuffer buffer = image.getPlanes()[0].getBuffer();
        byte[] bytes = new byte[buffer.capacity()];
        buffer.get(bytes);
        Bitmap bitmap= BitmapFactory.decodeByteArray(bytes,0,bytes.length,null);

        image.close();

        return bitmap;
    }

    private void startStillCaptureRequest() {
        try {
            mCaptureRequestBuilder = mCameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            mCaptureRequestBuilder.addTarget(mImageReader.getSurface());
            mCaptureRequestBuilder.set(CaptureRequest.JPEG_ORIENTATION, mTotalRotation);

            CameraCaptureSession.CaptureCallback stillCaptureCallback = new
                    CameraCaptureSession.CaptureCallback() {
                        @Override
                        public void onCaptureStarted(CameraCaptureSession session, CaptureRequest request, long timestamp, long frameNumber) {
                            super.onCaptureStarted(session, request, timestamp, frameNumber);

                            try {
                                createImageFileName();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    };

            mPreviewCaptureSession.capture(mCaptureRequestBuilder.build(), stillCaptureCallback, null);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    private void closeCamera() {
        if(mCameraDevice != null) {
            mCameraDevice.close();
            mCameraDevice = null;
        }
        if(mMediaRecorder != null) {
            mMediaRecorder.release();
            mMediaRecorder = null;
        }
    }

    private void startBackgroundThread() {
        mBackgroundHandlerThread = new HandlerThread("Camera2VideoImage");
        mBackgroundHandlerThread.start();
        mBackgroundHandler = new Handler(mBackgroundHandlerThread.getLooper());
    }

    private void stopBackgroundThread() {
        mBackgroundHandlerThread.quitSafely();
        try {
            mBackgroundHandlerThread.join();
            mBackgroundHandlerThread = null;
            mBackgroundHandler = null;
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    private void startStopwatch() {
        timestamps.clear();
        handler.post(stopwatchRunnable);
    }

    private void stopStopwatch() {
        handler.removeCallbacks(stopwatchRunnable);
    }
    private void recordTimestamp() {
        long currentTime = System.nanoTime();
        timestamps.add(currentTime);
    }

    private static int sensorToDeviceRotation(CameraCharacteristics cameraCharacteristics, int deviceOrientation) {
        int sensorOrienatation = cameraCharacteristics.get(CameraCharacteristics.SENSOR_ORIENTATION);
        deviceOrientation = ORIENTATIONS.get(deviceOrientation);
        return (sensorOrienatation + deviceOrientation + 360) % 360;
    }

    private static Size chooseOptimalSize(Size[] choices, int width, int height) {
        List<Size> bigEnough = new ArrayList<Size>();
        for(Size option : choices) {
            if(option.getHeight() == option.getWidth() * height / width &&
                    option.getWidth() >= width && option.getHeight() >= height) {
                bigEnough.add(option);
            }
        }
        if(bigEnough.size() > 0) {
            return Collections.min(bigEnough, new CompareSizeByArea());
        } else {
            return choices[0];
        }
    }

    private void createVideoFolder() {
        File movieFile = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES);
        mVideoFolder = new File(movieFile, "camera2VideoImage");
        if(!mVideoFolder.exists()) {
            mVideoFolder.mkdirs();
        }
    }

    private File createVideoFileName() throws IOException {
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String prepend = "VIDEO_" + timestamp + "_";

        file = new File(mFrameFolder, prepend+"_timestamp.xlsx");
        File videoFile = File.createTempFile(prepend, ".mp4", mVideoFolder);
        mVideoFileName = videoFile.getAbsolutePath();
        return videoFile;
    }

    private void createImageFolder() {
        File imageFile = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        mImageFolder = new File(imageFile, "camera2VideoImage");
        if(!mImageFolder.exists()) {
            mImageFolder.mkdirs();
        }
    }

    private File createImageFileName() throws IOException {
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String prepend = "IMAGE_" + timestamp + "_";
        File imageFile = File.createTempFile(prepend, ".jpg", mImageFolder);
        mImageFileName = imageFile.getAbsolutePath();
        return imageFile;
    }

    private void setUpFolderPath() {
        // Get the directory for storing the frames
        File directory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        mFrameFolder = new File(directory, "Timestamps");
        if (!mFrameFolder.exists()) {
            mFrameFolder.mkdirs();
        }

//        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
//        String prepend = "FRAME_" + timestamp + "_";
//        try {
//            File frameFile = File.createTempFile(prepend, ".mp4", mFrameFolder);
//            filePath = frameFile.getAbsolutePath();
//        }
//        catch (Exception e){
//            Toast.makeText(this, "Frame: "+e, Toast.LENGTH_SHORT).show();
//        }
        // Set the file path with a unique name
//        String fileName = "frame_" + System.currentTimeMillis() + ".yuv"; // Adjust the file extension as needed
//        filePath = new File(directory, fileName).getAbsolutePath();
    }

    private void storeFrames(){
        for(int i=0;i<vImage.size();i++){
            //get image buffer
            count++;
            byte[] bytes = vImage.get(i);
            Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length,null);
            // create bitmap
            // Save the frame data and timestamp to a file
            saveFrameToFile(bitmap, vTime.get(i));
        }
        vImage.clear();
        vTime.clear();
        Toast.makeText(this, Integer.toString(count), Toast.LENGTH_SHORT).show();
    }

    private void saveFrameToFile(Bitmap bitmap, long timestamp) {
        count++;
        // Set up the file path for the current frame
        String fileName = "frame_" + timestamp + ".jpg"; // Custom file extension
        File file = new File(mFrameFolder, fileName);
//        Bitmap bitmap = imageToBitmap(image);

        // Save the bitmap to the file
        if (file.exists()) file.delete ();
        try {
            FileOutputStream out = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
            out.flush();
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Save the frame data and timestamp to the file
//        FileOutputStream fileOutputStream = null;
//        DataOutputStream dataOutputStream = null;
//        try {
//            fileOutputStream = new FileOutputStream(filePath);
//            dataOutputStream = new DataOutputStream(fileOutputStream);
//
//            // Write the timestamp as a long value
//            dataOutputStream.writeLong(timestamp);
//
//            // Write the frame data
//            dataOutputStream.write(frameData);
//        } catch (IOException e) {
//            // Handle file write exception
//        } finally {
//            if (dataOutputStream != null) {
//                try {
//                    dataOutputStream.close();
//                } catch (IOException e) {
//                    // Handle file close exception
//                }
//            }
//            if (fileOutputStream != null) {
//                try {
//                    fileOutputStream.close();
//                } catch (IOException e) {
//                    // Handle file close exception
//                }
//            }
//        }
    }

    private void checkWriteStoragePermission() {
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
            if(ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED) {
                if(take){
                    lockFocus();
                }
                else{
                    try {
                        createVideoFileName();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    if( mIsRecording) {

                        vImage.clear();
                        vTime.clear();
                        startRecord();
                        try {
                            mMediaRecorder.start();
                        }
                        catch (Exception e){
                            Toast.makeText(this, "Start Error: "+e, Toast.LENGTH_SHORT).show();
                        }
                        linear.setVisibility(View.INVISIBLE);
                        linear1.setVisibility(View.INVISIBLE);
                        flipCamera.setVisibility(View.INVISIBLE);
                        mChronometer.setBase(SystemClock.elapsedRealtime());
                        mChronometer.setVisibility(View.VISIBLE);
                        mChronometer.start();
                        startStopwatch();
                    }
                }
            } else {
                if(shouldShowRequestPermissionRationale(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                    Toast.makeText(this, "app needs to be able to save videos", Toast.LENGTH_SHORT).show();
                }
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_WRITE_EXTERNAL_STORAGE_PERMISSION_RESULT);
                checkWriteStoragePermission();
            }
        }
        else {
            if(take){
                lockFocus();
            }
            else{
                try {
                    createVideoFileName();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if(mIsRecording) {

                    vImage.clear();
                    vTime.clear();
                    startRecord();
                    mMediaRecorder.start();
                    linear.setVisibility(View.INVISIBLE);
                    linear1.setVisibility(View.INVISIBLE);
                    flipCamera.setVisibility(View.INVISIBLE);
                    mChronometer.setBase(SystemClock.elapsedRealtime());
                    mChronometer.setVisibility(View.VISIBLE);
                    mChronometer.start();
                    startStopwatch();
                }
            }
        }
    }

    private void setupMediaRecorder() throws IOException {
        try {
            mMediaRecorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
            mMediaRecorder.setOutputFile(mVideoFileName);
            mMediaRecorder.setOrientationHint(mTotalRotation);
            mMediaRecorder.setAudioSource(MediaRecorder.AudioSource.DEFAULT);
            mMediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            mMediaRecorder.setVideoSize(1920,1080);
            mMediaRecorder.setVideoEncodingBitRate(20000000);

            mMediaRecorder.setCaptureRate(40);
            mMediaRecorder.setVideoFrameRate(40);
            mMediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
            mMediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            mMediaRecorder.prepare();
        } catch (Exception e){
            Toast.makeText(this, "Prepare 1 Error: "+e, Toast.LENGTH_SHORT).show();
        }
    }

    private void lockFocus() {
        mCaptureState = STATE_WAIT_LOCK;
        mCaptureRequestBuilder.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_START);
        try {
//            if(mIsRecording) {
//                mRecordCaptureSession.capture(mCaptureRequestBuilder.build(), mRecordCaptureCallback, mBackgroundHandler);
//                Toast.makeText(this, "Record", Toast.LENGTH_SHORT).show();
//            } else {
                mPreviewCaptureSession.capture(mCaptureRequestBuilder.build(), mPreviewCaptureCallback, mBackgroundHandler);
                Toast.makeText(this, "Image saved successfully", Toast.LENGTH_SHORT).show();
//            }
        } catch (CameraAccessException e) {
            Toast.makeText(this, "Capture Error: "+e, Toast.LENGTH_SHORT).show();
        }
    }
    public void saveVectorToExcel() {
        // Create a new workbook
        HSSFWorkbook hssfWorkbook = new HSSFWorkbook();
        HSSFSheet hssfSheet = hssfWorkbook.createSheet("Timestamps");

        // Iterate over the vector and write data to cells
        int rowNum = 0;
        int ind=0;
        HSSFRow hssfRow = hssfSheet.createRow(rowNum++);
        HSSFCell hssfCell = hssfRow.createCell(0);
        hssfCell.setCellValue("CIR Data time");
        hssfCell = hssfRow.createCell(1);
        hssfCell.setCellValue("Frame time");
        for (int i=0;i<timestamps.size(); i++) {
            while(ind<vTime.size()-1 && timestamps.get(i)>=vTime.get(ind+1)) ind++;
            hssfRow = hssfSheet.createRow(rowNum++);
            hssfCell = hssfRow.createCell(0);
            hssfCell.setCellValue(timestamps.get(i));
            hssfCell = hssfRow.createCell(1);
            hssfCell.setCellValue(vTime.get(ind));
        }

        // Save the workbook to a file
        try (FileOutputStream fileOut = new FileOutputStream(file)) {
            hssfWorkbook.write(fileOut);
            if (fileOut!=null){
                fileOut.flush();
                fileOut.close();
            }
            Toast.makeText(this, "Timestamp mapping saved successfully!", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Close the workbook
        try {
            hssfWorkbook.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}



//package com.example.camx;
//
//import androidx.annotation.NonNull;
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.core.app.ActivityCompat;
//
//import android.content.Context;
//import android.content.pm.PackageManager;
//import android.graphics.SurfaceTexture;
//import android.hardware.camera2.CameraAccessException;
//import android.hardware.camera2.CameraCaptureSession;
//import android.hardware.camera2.CameraCharacteristics;
//import android.hardware.camera2.CameraDevice;
//import android.hardware.camera2.CameraManager;
//import android.hardware.camera2.CaptureRequest;
//import android.media.MediaRecorder;
//import android.os.Bundle;
//import android.os.Handler;
//import android.os.HandlerThread;
//import android.util.Log;
//import android.util.Range;
//import android.view.Surface;
//import android.view.SurfaceView;
//import android.view.TextureView;
//import android.widget.Toast;
//
//import java.util.Arrays;
//
//public class MainActivity extends AppCompatActivity {
//    private static final String TAG = "MainActivity";
//    private static final int REQUEST_CAMERA_PERMISSION = 200;
//    private MediaRecorder mediaRecorder;
//    private SurfaceView surfaceView;
//    private Surface mediaRecorderSurface;
//
//    private CameraManager cameraManager;
//    private String cameraId;
//    private CameraDevice cameraDevice;
//    private CameraCaptureSession captureSession;
//
//    private TextureView textureView;
//    private boolean isRecording = false;
//    private Range<Integer> desiredFpsRange;
//
//    private HandlerThread backgroundThread;
//    private Handler backgroundHandler;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//
//        textureView = findViewById(R.id.textureView);
//
//        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
//
//        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
//            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);
//        } else {
//            openCamera();
//        }
////        openCamera();
//    }
//
//    private void openCamera() {
//        try {
//            cameraId = getCameraId();
//
//            if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
//                ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);
//
//                return;
//            }
//            cameraManager.openCamera(cameraId, new CameraDevice.StateCallback() {
//                @Override
//                public void onOpened(@NonNull CameraDevice camera) {
//                    cameraDevice = camera;
//                    startPreview();
//                }
//
//                @Override
//                public void onDisconnected(@NonNull CameraDevice camera) {
//                    cameraDevice.close();
//                }
//
//                @Override
//                public void onError(@NonNull CameraDevice camera, int error) {
//                    cameraDevice.close();
//                }
//            }, null);
//        } catch (CameraAccessException e) {
//            e.printStackTrace();
//        }
//    }
//
//    private String getCameraId() throws CameraAccessException {
//        String[] cameraIds = cameraManager.getCameraIdList();
//        for (String id : cameraIds) {
//            CameraCharacteristics characteristics = cameraManager.getCameraCharacteristics(id);
//            Integer facing = characteristics.get(CameraCharacteristics.LENS_FACING);
//            if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
//                return id;
//            }
//        }
//        throw new IllegalStateException("No suitable camera found.");
//    }
//
//    private void startPreview() {
//        if (cameraDevice == null || !textureView.isAvailable()) {
//            return;
//        }
//
//        try {
//            SurfaceTexture surfaceTexture = textureView.getSurfaceTexture();
//            assert surfaceTexture != null;
//            surfaceTexture.setDefaultBufferSize(textureView.getWidth(), textureView.getHeight());
//            Surface surface = new Surface(surfaceTexture);
//
//            mediaRecorderSurface = surfaceView.getHolder().getSurface();
//
//            cameraDevice.createCaptureSession(
//                    Arrays.asList(surface, mediaRecorderSurface),
//                    new CameraCaptureSession.StateCallback() {
//                        @Override
//                        public void onConfigured(@NonNull CameraCaptureSession session) {
//                            captureSession = session;
//                            updatePreview();
//                        }
//
//                        @Override
//                        public void onConfigureFailed(@NonNull CameraCaptureSession session) {
//                            Log.e(TAG, "Capture session configuration failed.");
//                        }
//                    },
//                    null
//            );
//        } catch (CameraAccessException e) {
//            e.printStackTrace();
//        }
//    }
//
//    private void updatePreview() {
//        if (cameraDevice == null || captureSession == null) {
//            return;
//        }
//
//        try {
//            CaptureRequest.Builder requestBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
//            SurfaceTexture surfaceTexture = textureView.getSurfaceTexture();
//            assert surfaceTexture != null;
//            surfaceTexture.setDefaultBufferSize(textureView.getWidth(), textureView.getHeight());
//            Surface surface = new Surface(surfaceTexture);
//            requestBuilder.addTarget(surface);
//            requestBuilder.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, desiredFpsRange);
//
//            captureSession.setRepeatingRequest(requestBuilder.build(), null, null);
//        } catch (CameraAccessException e) {
//            e.printStackTrace();
//        }
//    }
////    private void startRecording() {
////        // Check if recording is already in progress
////        if (isRecording) {
////            return;
////        }
////
////        // Update the desired frame rate range for video recording
////        desiredFpsRange = new Range<>(30, 30); // Change this to desired frame rate range
////
////        // Start recording
////        // ...
////    }
////
////    private void stopRecording() {
////        // Check if recording is already stopped
////        if (!isRecording) {
////            return;
////        }
////
////        // Stop recording
////        // ...
////    }
////
////    @Override
////    protected void onResume() {
////        super.onResume();
////        startBackgroundThread();
////
////        if (textureView.isAvailable()) {
////            openCamera();
////        } else {
////            textureView.setSurfaceTextureListener(textureListener);
////        }
////    }
////
////    @Override
////    protected void onPause() {
////        closeCamera();
////        stopBackgroundThread();
////        super.onPause();
////    }
////
////    private void closeCamera() {
////        if (captureSession != null) {
////            captureSession.close();
////            captureSession = null;
////        }
////
////        if (cameraDevice != null) {
////            cameraDevice.close();
////            cameraDevice = null;
////        }
////    }
////
//    private void startBackgroundThread() {
//        backgroundThread = new HandlerThread("CameraBackgroundThread");
//        backgroundThread.start();
//        backgroundHandler = new Handler(backgroundThread.getLooper());
//    }
//
//    private void stopBackgroundThread() {
//        if (backgroundThread != null) {
//            backgroundThread.quitSafely();
//            try {
//                backgroundThread.join();
//                backgroundThread = null;
//                backgroundHandler = null;
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//        }
//    }
//
//    private TextureView.SurfaceTextureListener textureListener = new TextureView.SurfaceTextureListener() {
//        @Override
//        public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int width, int height) {
//            openCamera();
//        }
//
//        @Override
//        public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int width, int height) {
//        }
//
//        @Override
//        public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
//            return false;
//        }
//
//        @Override
//        public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {
//        }
//    };
//
//    @Override
//    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//        if (requestCode == REQUEST_CAMERA_PERMISSION) {
//            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                openCamera();
//            } else {
//                Toast.makeText(this, "Camera permission denied.", Toast.LENGTH_SHORT).show();
//                finish();
//            }
//        }
//    }
//}